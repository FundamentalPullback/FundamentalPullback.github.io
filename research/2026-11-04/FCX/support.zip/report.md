# FCX · Cobre, recuperación operativa e inversión nueva

Corte de investigación: 4 noviembre 2026, 21:52 UTC. Importes en millones USD salvo precios y unidades indicadas. Investigación parcial; auditoría independiente completada, con las reservas indicadas. Sin valoración por acción, owner FCF, puente integral ni entrada aprobada.

## Conclusión

El beneficio crece, pero no basta con extrapolar precios de metales elevados o tratar toda la caja consolidada como propia de FCX. Q3 combina cobre más caro, menor volumen, recuperación gradual de Grasberg y costes del incidente de septiembre 2025. Hoy la compañía aprobó Bagdad: una inversión adicional de 4.500 que debe financiarse antes de reconocer su producción futura.

La investigación incorpora esa noticia y no repite las listas A005/A008/A011/A014. El último 10-Q identificado en submissions SEC al corte es junio; septiembre procede del comunicado y anexos del 8-K del 27octubre. No se simula que exista un 10-Q Q3 ni se trasladan a septiembre automáticamente las notas de junio. La siguiente fase requiere valoración por activos/participaciones, precios de ciclo, calendario de inversión y derechos mineros finitos, no un DCF consolidado perpetuo simplificado.

## Historia y alcance

| Periodo | Ventas | EBIT | NI atribuible | EPS directo | CFO | PPE | SBC | CFO−PPE |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| FY2019 | 14,402.000 | 1,091.000 | -239.000 | -0.170 | 1,482.000 | 2,652.000 | 63.000 | -1,170.000 |
| FY2020 | 14,198.000 | 2,437.000 | 599.000 | 0.410 | 3,017.000 | 1,961.000 | 99.000 | 1,056.000 |
| FY2021 | 22,845.000 | 8,366.000 | 4,306.000 | 2.900 | 7,715.000 | 2,115.000 | 98.000 | 5,600.000 |
| FY2022 | 22,780.000 | 7,037.000 | 3,468.000 | — | 5,139.000 | 3,469.000 | 95.000 | 1,670.000 |
| FY2023 | 22,855.000 | 6,225.000 | 1,848.000 | 1.280 | 5,279.000 | 4,824.000 | 109.000 | 455.000 |
| FY2024 | 25,455.000 | 6,864.000 | 1,889.000 | 1.300 | 7,160.000 | 4,808.000 | 109.000 | 2,352.000 |
| FY2025 | 25,915.000 | 6,518.000 | 2,204.000 | 1.520 | 5,610.000 | 4,494.000 | 121.000 | 1,116.000 |
| Q4_2024 | 5,720.000 | 1,243.000 | 274.000 | 0.190 | 1,436.000 | 1,239.000 | 15.000 | 197.000 |
| Q1_2025 | 5,728.000 | 1,303.000 | 352.000 | 0.240 | 1,058.000 | 1,172.000 | 54.000 | -114.000 |
| Q2_2025 | 7,582.000 | 2,432.000 | 772.000 | 0.530 | 2,195.000 | 1,261.000 | 20.000 | 934.000 |
| Q3_2025 | 6,972.000 | 1,972.000 | 674.000 | 0.460 | 1,689.000 | 1,056.000 | 24.000 | 633.000 |
| Q4_2025 | 5,633.000 | 811.000 | 406.000 | 0.280 | 668.000 | 1,005.000 | 23.000 | -337.000 |
| Q1_2026 | 6,234.000 | 2,137.000 | 881.000 | 0.610 | 1,495.000 | 973.000 | 68.000 | 522.000 |
| Q2_2026 | 7,029.000 | 2,003.000 | 984.000 | 0.680 | 2,048.000 | 1,104.000 | 35.000 | 944.000 |
| Q3_2026 | 7,546.000 | 2,353.000 | 1,174.000 | 0.810 | 1,981.000 | 1,159.000 | 28.000 | 822.000 |
| TTM_Q3_2025 | 26,002.000 | 6,950.000 | 2,072.000 | 1.420 | 6,378.000 | 4,728.000 | 113.000 | 1,650.000 |
| TTM_Q3_2026 | 26,442.000 | 7,304.000 | 3,445.000 | 2.380 | 6,192.000 | 4,241.000 | 154.000 | 1,951.000 |


El EPS directo de FY 2022 no se retuvo en el conjunto reproducible y permanece nulo, no cero; ese año se utiliza solo como contexto del ciclo.

Ledger de datos publicados y fórmulas, con ciclo FY2019–2025, últimos cuatro trimestres y TTM comparativo. Se separan beneficio consolidado y atribuible. EPS TTM es suma de trimestres directos, no EPS publicado TTM ni resta de EPS acumulados. CFO menos capex consolidado no es flujo libre atribuible a los accionistas de FCX.

TTM septiembre 2026: ventas 26.442, EBIT7.304, NI consolidado 5.031 y atribuible 3.445. CFO6.192−capex 4.241=1.951 consolidado, antes de minoritarios y SBC154. La historia marca una diferencia no conciliada de 25 en CFO: Q4 original 2025 publicó 693, mientras FY5.610 menos 9Mcomparativo actualizado 4.942 implica 668. Se usa la base acumulada reciente coherente para TTM, sin ocultar el Q4 directo ni afirmar una reclasificación o revisión verificada. La alternativa que suma el Q4 publicado da CFO TTM 6.217 y CFO−capex 1.976; ambas rutas quedan visibles. No se concluye irregularidad contable a partir de esa diferencia.

## Beneficio, precios y volúmenes

Q3 ingresos 7.546 y EBIT2.353, margen 31,18%; NI atribuible 1.174, EPS0,81. Las ventas de cobre 749 millones de libras bajaron 23,34% frente a 977, mientras el precio realizado 6,54 subió 39,74% frente a 4,68. La producción 832 difiere de las ventas: no multiplicar producción por precio y llamarlo ingreso reconocido. Las ventas de oro 105 mil onzas frente a 336 también reflejan la recuperación y el calendario de refino; unas 60 mil onzas se desplazaron a Q4, no desaparecieron ni son ingreso garantizado.

En nueve meses se reconoció ganancia de seguro 699 por el incidente de mud rush y se cobró 699. El efecto después de impuestos y participación ajena fue 207 atribuible a FCX, no 699. Las conciliaciones ajustadas de la empresa separan esa ganancia junto con costes de recuperación, DD&A y otros conceptos; no se resta nuevamente el seguro a su resultado ajustado sin revisar la conciliación.

Costes de instalación ociosa, recuperación y restauración fueron 244 en Q3 y 934 en nueve meses, más DD&A asociada 236 acumulada. No se eliminan todos para valorar capacidad normal sin financiar rehabilitación y ramp-up. El coste neto de caja por libra 2,07 no incluye todos esos costes y depende de créditos por subproductos; coste de producción/entrega 3,24 tampoco representa capex, fiscalidad y rendimiento del accionista.

El EBIT Q3 incluye ajustes de precios provisionales de ventas previas 52 y liberación de beneficios intercompañía 24. Son efectos distintos, sensibles a precios y embarques; no confundirlos con crecimiento estructural ni aplicar automáticamente toda la diferencia como addback. La guía fiscal 2026 de 30% consolidado depende de precios/volúmenes y mezcla jurisdiccional; Perú 40%, Indonesia 36% y EEUU10% estimados no justifican una tasa universal permanente.

## Caja: puentes útiles, no owner FCF

Nueve meses CFO5.524−capex 3.236=2.288 consolidado. Excluir el cobro extraordinario de seguro 699 deja 1.589. Restar además distribuciones efectivas a minoritarios 625, principal de finance leases 32 y SBC131 da 801 como diagnóstico de desembolsos, no owner FCF: las distribuciones reales no equivalen al derecho económico de minoritarios sobre caja generada, y su calendario puede solaparse con los fondos del seguro. No se extrapola 801 ni se usa como ancla de DCF.

Los inventarios absorbieron 601 y se mantuvieron diferencias entre producción, refino y ventas. El capital de crecimiento no es caja libre actual aunque la política lo llame discrecional. La guía 2026 de CFO8.500 y capex 4.400 se anunció antes de la aprobación Bagdad y supone precios Q4 cobre 6,50, oro 4.000 y molibdeno 32. No es consenso, hecho realizado ni previsión normalizada para los siguientes doce meses. La distribución de hasta 50% de caja disponible de la política tiene condiciones y discreción del consejo, no compromiso de dividendos.

## Participaciones y balance

PTFI se consolida al 100%, pero FCX posee 48,76%. Su economía atribuible fue aproximadamente 81% hasta 2022 y 48,76% desde 2023, por lo que el beneficio accionista de 2021–2022 no es un run-rate comparable con la estructura actual. Cerro Verde pasó de 55,08% a 55,66% en mayo, con desembolso 107. Morenci se incluye ya por consolidación proporcional 72%: no volver a multiplicar ese EBIT/caja por 72%. Además, PTFI posee 66% de PT Smelting, por lo que hay participaciones ajenas anidadas. No aplicar un único porcentaje de propiedad a todo el grupo.

Balance septiembre: deuda contable 9.398 y caja 4.335 dan deuda neta consolidada 5.063. El indicador de política de 1.826 excluye 3.237 de deuda de instalaciones downstream de PTFI. Esa exclusión no cancela la deuda y no es el puente al equity. La caja restringida de 424 se presenta aparte; no sumarla como disponible.

La empresa publica caja neta disponible aproximadamente 3.300 después de participación ajena y retenciones, con redondeos, frente a 4.300 de caja consolidada. No deducir nuevamente minoritarios/impuestos de los 3.300. Ni esa cifra redondeada ni el patrimonio contable de minoritarios 12.632 representan una valoración de las participaciones ajenas. Los saldos posteriores a septiembre y el reparto de activos/pasivos siguen por conciliar.

Obligaciones ambientales y ARO:374 corrientes más 5.609 no corrientes=5.983. Pagos 151 y cargos 237 en nueve meses exigen separar gasto recurrente y obligaciones históricas antes de sumar una reserva al puente; no duplicar automáticamente valor presente de obligación y todos sus pagos en DCF. Leases de largo plazo 958 excluyen corriente y no se hacen pasar por saldo total. Dividendo común pendiente 218 al balance: al comparar con precio posterior al pago del 2noviembre habría que conciliarlo una sola vez, no presentar caja de septiembre como saldo posterior actual.

Revolver FCX3.000, prácticamente libre salvo cartas de crédito 5; PTFI1.750 con 250 dispuestos y Cerro Verde 350 no dispuesto. Facilidades extendidas a 2031. Vencimientos de notas PTFI700 en abril 2027 y FCX600 en segundo semestre 2027, entre otros; capacidad de crédito no es efectivo libre.

## Bagdad, Grasberg y derechos

El 4noviembre el consejo aprobó 4.500 para expansión/modernización Bagdad, operación totalmente propia. Plan:20% en 2027 (900),30–35% en 2028 (1.350–1.575), resto 2029–2030. Producción inicial objetivo mediados 2030, incremento anual a largo plazo 225 millones de libras de cobre y 12 millones de molibdeno. Son estimaciones de proyecto, expuestas a costes y ejecución. No añadir 225 desde 2027 ni contabilizar todo 4.500 como gasto ya realizado; tampoco mantener el crecimiento sin esa inversión.

Kucing Liar es otro proyecto: aproximadamente 1.600 invertidos y 4.000 adicionales estimados hasta 2033; calendario de inicio bajo revisión. Su producción permite continuidad y no equivale íntegramente a aumento neto sobre minas que se agotan. La vida de reservas de Bagdad no determina la de todos los activos.

El molino de PTFI tuvo throughput Q3 de 141 mil toneladas diarias, equivalente al 67% de capacidad, con objetivo 80% a mediados 2027 y aproximadamente plena capacidad a fin 2027. El smelter reinició en agosto; riesgos de agua, manejo de material y seguridad subsisten. El MOU de febrero plantea extender derechos más allá de 2041, mantener 48,76% hasta 2041 y aproximadamente 37% desde 2042, pero requiere licencia IUPK modificada y formalización. No tratar un MOU como concesión definitiva ni perpetuar 48,76% en terminal. El cumplimiento de condiciones de licencias existentes también debe revisarse.

## Pares operativos y límites de valoración

Southern Copper Q3 reporta ventas 4.696,6 y EBIT2.815,1, margen 59,94%. CFO2.224,3 menos inversión 515,8 da 1.708,5 antes de otras partidas. Su coste neto 0,09 por libra está reducido por créditos de subproductos favorecidos por precios altos, no prueba coste económico casi cero. Mezcla, leyes, propiedad y capex difieren. Tiene dividendo efectivo y de acciones anunciado para noviembre, relevante si se construye comparación por acción; aquí no se calcula múltiplo.

BHP Copper FY terminadojunio 2026: ingresos 29.031 y Underlying EBITDA18.187. Es EBITDA ajustado y un periodo/perímetro distinto, no EBIT GAAP de FCX. El auge de precios ayuda a ambos, pero no demuestra que los precios actuales sean permanentes. Pares homogéneos, valor de minoritarios y obligaciones por activo siguen pendientes.

Faltan escenarios coherentes de cobre/oro/molibdeno de ciclo, producción por activos y ley, reposición/expansión/rehabilitación, impuestos locales, restricciones de distribución y derechos mineros. No se publica un rango, WACC ni inverso improvisado que dependa de mantener precios máximos o de una terminal perpetua sin concesión. La cotización por debajo del escáner antiguo no sustituye esos pasos.

## Precio, calendario y ficha

Referencia Yahoo regularMarketPrice 62,60, timestamp 4nov 16:02:43ET, frente a StockAnalysis cierre 62,64 a 16:00. Difieren y los tiempos no son idénticos: no cierre único certificado. Escáner real 13oct 71,575 frente a historial 72,42 sin ajustar y 72,26 ajustado: ninguna comparación resuelve la diferencia. Mantener fecha y fuente, no reemplazar silenciosamente el dato histórico. QP80/Opportunity 85 y Stage 2 antiguos no son autorización técnica actual.

Q3 ya publicado 27octubre. La siguiente fecha exacta no se identificó en las fuentes oficiales revisadas; no se inventa enero. La aprobación Bagdad ya ocurrió, no es evento pendiente. Catalizadores: nuevo presupuesto capex, actualización operativa, formalización IUPK y próximos resultados, cada uno con incertidumbres propias.

### Pros ES
- La recuperación de Grasberg y los proyectos propios ofrecen crecimiento potencial, con inversión y calendario identificados.
- El balance distingue deuda consolidada de la métrica de política y caja atribuible de caja total.
### Contras ES
- El beneficio depende de metales más caros mientras los volúmenes vendidos caen; el seguro no es caja recurrente.
- Bagdad requiere nueva inversión y los derechos y participaciones de Indonesia impiden una terminal perpetua simplificada.
- Falta el 10-Q de septiembre, el cierre de precios discrepa y no hay valoración integral ni entrada aprobada.
### Pros EN
- Grasberg recovery and owned projects offer potential growth with identified investment and timing requirements.
- The balance-sheet review distinguishes consolidated debt from the policy metric and attributable cash from total cash.
### Cons EN
- Earnings depend on higher metal prices while sales volumes decline; insurance proceeds are not recurring cash flow.
- Bagdad requires new investment and Indonesia rights and ownership prevent a simplified perpetual terminal value.
- The September 10-Q is unavailable, closing-price references disagree, and no integral valuation or entry is approved.

## Fuentes y soporte

- Q3: https://www.sec.gov/Archives/edgar/data/831259/000083125926000045/a3q2026exhibit991.htm
- Q2: https://www.sec.gov/Archives/edgar/data/831259/000083125926000036/fcx-20260630.htm
- FY2025: https://www.sec.gov/Archives/edgar/data/831259/000083125926000012/fcx-20251231.htm
- Bagdad4nov: https://investors.fcx.com/investors/news-releases/news-release-details/2026/Freeport-Announces-Plans-to-Boost-U-S--Copper--Molybdenum-Production/default.aspx
- IR/calendario: https://investors.fcx.com/investors/default.aspx
- Precios: https://finance.yahoo.com/quote/FCX/ y https://stockanalysis.com/stocks/fcx/history/
- SCCO: https://www.sec.gov/Archives/edgar/data/1001838/000110465926117588/scco-ex99d1.htm
- BHP: https://www.sec.gov/Archives/edgar/data/811809/000119312526354647/bhp-20260630.htm

Datos, conciliaciones y límites reproducibles; no se modifican posiciones, operaciones ni reglas del plan.
