from pathlib import Path
import json
P=Path(__file__).parent
# Manual transcription from FY2025 10-K MD&A and Note 17, FY2024 10-K MD&A.
sources={'FY2025':'https://www.sec.gov/Archives/edgar/data/1035002/000162828026011499/vlo-20251231.htm','FY2024':'https://www.sec.gov/Archives/edgar/data/1035002/000103500225000005/vlo-20241231.htm'}
rows={}
for year,ref,adj,margin,vol,rd,eth,ethadj,corp,days in [(2023,11511,11528,19087,2979,852,553,569,-1058,365),(2024,3971,3988,11325,2912,507,288,315,-1011,366),(2025,4040,5273,13403,2988,-156,374,374,-1077,365)]:
 rows[str(year)]={'refining_EBIT':ref,'refining_adjusted_EBIT':adj,'refining_margin':margin,'throughput_thousand_bpd':vol,'annual_throughput_million_barrels_calculated':vol*days/1000,'refining_adjusted_EBIT_per_barrel_calculated':round(adj/(vol*days/1000),4),'refining_margin_per_barrel_calculated':round(margin/(vol*days/1000),4),'renewable_diesel_EBIT_gross_consolidated':rd,'ethanol_EBIT':eth,'ethanol_adjusted_EBIT':ethadj,'corporate_and_eliminations_EBIT':corp}
notes=[
'USD millions except throughput and per-barrel metrics. FY2024 has 366 days. Per-barrel metrics are calculations using rounded reported throughput, not exact company-reported metrics.',
'2025 Refining adjusted EBIT adds37 LIFO liquidation charge,50 retention/separation costs,1131 asset impairment,15 other operating expenses to4040 reported. No SBC addback.',
'2024 Refining adjusted EBIT adds17 other operating expenses; 2023 adds17. Ethanol adjusted adds27 in2024 and16 in2023.',
'DGD is50% owned but100% consolidated. Renewable Diesel EBIT is gross and must not be treated as100% attributable Valero. Corporate and eliminations reconciles aggregate segment EBIT to consolidated EBIT.',
'FY2025 gross capital investments1888 includes796 PP&E capex+1089 deferred turnaround/catalyst+3 nonconsolidated JV investment. Attributable Valero1797 removes85 other DGD member and6 other VIE capex. Gross2023/24/25 capital investments1916/2057/1888; calculated attributable1758/1888.5/1797; company2024 reports1888 due rounding.',
'9M2026 capital investment1230 includes661 PP&E capex+569 turnaround/catalyst; attributable1205. Q3 standalone DGD PP&E capex is -3 (9M4 minus6M7). Treat as reported net expenditure difference, not negative replacement cost; no clear grant explanation located.',
'2026 forecast gross and attributable capital investments approximately2000, includes250 Port Arthur incident related expenditures; attributable sustaining approximately1700. Expected insurance is not collected cash and must not be netted before receipt.',
'Full SBC expense FY2023/24/25=107/100/117. Equity recognition94/89/100 differs; quarterly full SBC remains null rather than falsely substituting equity recognition. Retain SBC in EBIT; no owner-cash claim from an incomplete quarterly SBC adjustment.',
'FY2025 pension asset948 and gross pension liabilities237 (28 current,209 long-term) yield net funded surplus711; other postretirement liabilities235 (21 current,214 long-term). Gross benefit debt-like liabilities472; pension asset is not unrestricted cash.',
'FY2025 total ARO382, opening38 + incurred337 + accretion15 - settlements8. Benicia incurred337; do not claim337 is separately disclosed year-end Benicia ARO. FY2025 Note8 balance-sheet liability for unrecognized tax benefits441 (all long-term), versus Note15 gross UTB rollforward315 excluding interest/penalties. Difference126 is unreconciled; do not attribute it to interest/penalties, which are described as immaterial. Use441 as balance-sheet proxy if appropriate and never add315 to441. Environmental liabilities32 current+243 long-term=275 are separate fromARO382 and benefit liabilities472.',
'TTM2026Q3 revenue153327,EBIT17575,parentNI12945,CFO15959,DA3078,capital investments1642. PriorTTM revenue123071,EBIT1954,parentNI1495,CFO4839,DA3039,capital investments2023. Current cycle cannot be perpetuated as normalized economics.',
'Clean-fuel credit regimes, RIN costs, crack spreads, closure of Benicia, and capacity/throughput changes alter comparability. Revenue includes oil-price effects and certain foreign excise taxes, so margin dollars and throughput matter more than sales growth alone.'
]
json.dump({'sources':sources,'segments':rows,'notes':notes},open(P/'segments_and_caveats.json','w'),indent=2)
print(json.dumps(rows,indent=2))
