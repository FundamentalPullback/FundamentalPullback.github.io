# STX: capacidad y rentabilidad récord, con reversión del ciclo financiada en escenarios

Corte: 4 de noviembre de 2026, 20:39 UTC. USD millones salvo acciones en millones, EPS y precio. Valoración exploratoria condicionada, de nivel screen-grade, revisada mediante auditoría independiente, manteniendo sus reservas. No cierre integral Stage 3, latestCompleted, Stage 3.5 ni entrada. Sin cambios de gestión u operaciones.

## 1. Resultado y alcance

El crecimiento operativo de Seagate es real, pero extrapolar el trimestre récord confundiría el punto actual del ciclo con su rentabilidad permanente. Q1 FY27 registra ingresos 4.233, EBIT GAAP 2.064 y margen operativo 48,76 %. En el TTM, ingresos 13.799 y EBIT 5.464. La transición HAMR, capacidad por disco, precios y disciplina de oferta pueden mejorar el negocio; no prueban demanda ni margen constantes durante diez años.

Escenarios exploratorios por acción: bajista 58,26, central 209,91 y favorable 498,32. Frente al cierre del 3 de noviembre de 606,38, ninguno alcanza el precio de referencia. No son probabilidades ni objetivos de cotización. Las hipótesis de crecimiento, margen, retorno de reinversión y tasa de descuento son del analista, no consenso ni compromisos de dirección. No hay techo de compra aprobado.

Se conserva la observación real del escáner del 5 de octubre: 886,235, QP 80, Opportunity 100, RSI 51,5 y Stage 2 Sí histórico. El historial de precios consultado muestra 887,09 ese día; diferencia de base/proveedor no reconciliada, no se reescribe el escáner. A008/A011 eran listas, no un modelo anterior que este informe replique. No se usa precio intradía del 4 de noviembre ni se convierte un filtro técnico antiguo en aprobación vigente.

## 2. Negocio y evidencia del ciclo

Seagate fabrica almacenamiento de alta capacidad, principalmente HDD. HAMR/Mozaic busca aumentar capacidad por disco y eficiencia de coste por terabyte. La cualificación con clientes, fabricación integrada, propiedad intelectual y fiabilidad son barreras relevantes; el riesgo de transición tecnológica, defectos, proveedores y concentración de compradores permanece. SSD y otras arquitecturas compiten en determinados usos, aunque coste por capacidad y patrones de carga difieren.

Q1 FY27 terminó el 2 de octubre de 2026: 13 semanas frente a 14 del comparativo. FY26 tuvo 53 semanas. El crecimiento publicado de ingresos es 61,0 %, no crecimiento por semana homogénea. Exabytes HDD enviados 220 frente a 182, con nearline 198 frente a 160. El volumen crece menos que los ingresos, compatible con precio/mix/capacidad y otros factores; no se divide ingreso total por exabytes para inventar un ASP HDD exacto. Centro de datos representa 81 % de ingresos frente a 80 %.

El margen bruto GAAP pasa de 39,4 % a 57,3 % y EBIT de 694 a 2.064. La expansión excede ampliamente la del volumen: sensibilidad a precios, mezcla y utilización es central. La dirección describe compromisos y mayor visibilidad comercial; no se valora cada acuerdo de capacidad como contrato irrevocable de caja sin términos de cancelación, precio y volumen. El modelo usa escenarios de ingresos, no una previsión detallada por exabyte o producto: esa simplificación limita su grado de confianza.

## 3. Historia, SBC e impuestos

| Periodo | Semanas | Ventas | EBIT GAAP | NI | EPS | CFO | Capex | FCF | SBC |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| FY2024 | 52.00 | 6,551.00 | 452.00 | 335.00 | 1.58 | 918.00 | 254.00 | 664.00 | 127.00 |
| FY2025 | 52.00 | 9,097.00 | 1,890.00 | 1,469.00 | 6.77 | 1,083.00 | 265.00 | 818.00 | 200.00 |
| FY2026 | 53.00 | 12,195.00 | 4,094.00 | 3,184.00 | 13.90 | 3,674.00 | 569.00 | 3,105.00 | 213.00 |
| Q2FY2025 | 13.00 | 2,325.00 | 488.00 | 336.00 | 1.55 | 221.00 | 71.00 | 150.00 | 49.00 |
| Q3FY2025 | 13.00 | 2,160.00 | 431.00 | 340.00 | 1.57 | 259.00 | 43.00 | 216.00 | 54.00 |
| Q4FY2025 | 13.00 | 2,444.00 | 568.00 | 488.00 | 2.24 | 508.00 | 83.00 | 425.00 | 59.00 |
| Q1FY2026 | 14.00 | 2,629.00 | 694.00 | 549.00 | 2.43 | 532.00 | 105.00 | 427.00 | 52.00 |
| Q2FY2026 | 13.00 | 2,825.00 | 843.00 | 593.00 | 2.60 | 723.00 | 116.00 | 607.00 | 53.00 |
| Q3FY2026 | 13.00 | 3,112.00 | 998.00 | 748.00 | 3.27 | 1,114.00 | 161.00 | 953.00 | 54.00 |
| Q4FY2026 | 13.00 | 3,629.00 | 1,559.00 | 1,294.00 | 5.58 | 1,305.00 | 187.00 | 1,118.00 | 54.00 |
| Q1FY2027 | 13.00 | 4,233.00 | 2,064.00 | 1,761.00 | 7.59 | 1,690.00 | 211.00 | 1,479.00 | 63.00 |
| TTM_Q1FY2026 | 53.00 | 9,558.00 | 2,181.00 | 1,713.00 | 7.79 | 1,520.00 | 302.00 | 1,218.00 | 214.00 |
| TTM_Q1FY2027 | 52.00 | 13,799.00 | 5,464.00 | 4,396.00 | 19.04 | 4,832.00 | 675.00 | 4,157.00 | 224.00 |


Tres ejercicios y ocho trimestres comparables más dos TTM, con reproducción desde hechos primarios. El TTM actual de 52 semanas contrasta con un TTM previo de 53; no se hace ajuste semanal mecánico a un negocio estacional/cíclico. EPS TTM es suma de EPS trimestrales publicados, no EPS anual oficial ni base para convertir beneficio en acciones actuales.

FCF TTM 4.157 = CFO 4.832 menos capex 675; después de SBC del estado de flujos 224, la sensibilidad es 3.933. Son medidas de caja histórica después de intereses/impuestos, no owner FCF certificado ni FCFF. FY26 pagó impuestos de caja de solo 40 frente a gasto fiscal de 506 y tuvo aumento de 528 en acumulados de gastos/impuestos/garantía. No se perpetúa ese desfase como caja libre.

Q1 SBC del estado de flujos es 63, pero los cargos relacionados con compensación retirados de la conciliación no GAAP son 77, incluyendo impuestos patronales. El modelo conserva los costes en EBIT GAAP y no resta SBC por segunda vez al FCFF. El promedio diluido de 232 millones no garantiza la dilución futura máxima. Los planes de acciones y recompensas siguen suponiendo coste; las recompras no son crecimiento gratuito por acción.

La provisión fiscal Q1 de 221 incluye beneficio discreto de aproximadamente 83, sobre todo relacionado con exceso de beneficios fiscales de acciones. El tipo legal de Singapur de 17 % no es una tasa mundial garantizada: incentivos y Pilar Dos afectan la mezcla. Se modelan tasas normalizadas 24/21/18 %, separadas de la caja histórica y sin monetizar el activo fiscal diferido de 1.161.

FY24 incluye ganancia no operativa por negocio SoC de 313 y por swap de 104, y beneficio operativo por venta y arrendamiento posterior de 30. No se extrapolan esas ganancias. Q1 FY27 tiene pérdida de deuda de 44 por rescates, fuera de EBIT; no se añade otra vez al operativo. Intevac se adquirió el 31 de marzo de 2025: precio 119, caja neta de adquisición 88 y 47 después de inversiones vendidas; son magnitudes distintas, no tres compras. Amortización adquirida TTM 7, frente a D&A total 280; el modelo no suma indiscriminadamente toda amortización a un margen ajustado.

## 4. Capital: ancla histórica y eventos posteriores

Caja al 2 de octubre 1.258. Los 112 de efectivo restringido figuran aparte en otros activos corrientes y se excluyen del puente; no se restan también de esos 1.258. Principal de deuda 2.383 según calendario de pagos, distinto de 2.372 de la tabla antes de costes de emisión y 2.351 netos contables. Revolver 1.300 no dispuesto no es efectivo.

Las notas canjeables de 2028 ya no estaban pendientes al 2 de octubre. Se liquidaron 35 de principal con aproximadamente 0,4 millones de acciones por exceso de conversión y luego 151 con aproximadamente 1,6 millones de acciones. Las acciones emitidas ya afectan la base de capital; no se añade deuda antigua ni todas las acciones otra vez al denominador. Los capped calls de nocional 1.500 y cap de 107,741 por acción seguían vigentes: el nocional no es efectivo ni valor razonable. No se les asigna valor en el caso central por falta de valoración/estado de liquidación completo; sensibilidad de activo 100 es un supuesto, no una tasación.

El dividendo de 0,74 por acción anunciado en FY26 era pagadero el 7 de octubre a titulares del 24 de septiembre. La nota 2 del Q1 reconoce dividendos a pagar de 170 al 2 de octubre. Se deduce esa obligación declarada una sola vez del puente, sin necesitar afirmar si el desembolso ya ocurrió ni reconstruir toda la caja de noviembre. No se usa un producto aproximado del dividendo por las acciones diluidas actuales, pues puede diferir del número de acciones con derecho al pago.

El 15 de octubre, después del balance, se rescataron 750 de principal de las notas 2032. Reducir deuda sin reducir caja daría valor ficticio. En el puente se considera que principal pagado cancela caja y deuda por igual, manteniendo deuda neta histórica, y se añade estrés de 81 por la pérdida contable esperada comunicada. Esa pérdida no es una prima de caja exacta: puede incluir costes de emisión y otros componentes. Sensibilidades 0/81/162 son supuestos de coste neto, no saldo actual certificado; no se incorpora CFO de octubre no publicado como caja adicional.

Reserva de UTB de 156, excluidos intereses/penalidades, se usa como estrés bruto, no como pago esperado. FY26 indicaba pasivo reconocido de 43 para posiciones fiscales inciertas, distinto del total bruto de beneficios no reconocidos. El tratamiento de atributos fiscales puede hacer conservador y parcialmente redundante restar el bruto mientras no se reconoce DTA; sensibilidad 43/0/doble lo muestra. No se certifican todas las obligaciones fiscales actuales o prestaciones laborales. Un estrés adicional de 200 ilustra otras reclamaciones no conciliadas, sin afirmar que exista pasivo de ese importe.

La demanda colectiva de valores tiene audiencia de aprobación final prevista para el 17 de noviembre de 2026, un evento jurídico concreto distinto de resultados. El acuerdo contempla 175, de los que 70 cubrirían aseguradoras; los 105 transferidos por la empresa a escrow durante Q1 están dentro de los 112 restringidos ya excluidos del efectivo de 1.258. No se descuenta de nuevo ese escrow ni se confunde con los otros 105 del acuerdo BIS. La aprobación preliminar y financiación del escrow no equivalen a resolución final; tampoco se reconoce un cobro de seguros como caja libre adicional.

BIS: obligación al 2 de octubre de 45 corriente y 60 no corriente, total 105, de un acuerdo original de 300. Pago Q1 de 15 ya está en CFO histórico; el FCFF futuro parte de EBIT sin aquella multa antigua y descuenta el saldo en el puente, no sus pagos otra vez. No se presupone realizado el siguiente pago de octubre solo porque tocara. La empresa declara dos de tres auditorías de cumplimiento terminadas; la orden de denegación suspendida depende de pagos y cumplimiento. Esto no equivale a cierre normativo integral ni a ausencia de riesgos de exportación.

Se reserva caja operativa de 8 % de ingresos TTM, 1.103,92, como hipótesis de liquidez, no mínimo impuesto por la empresa. Puente central: 1.258 − 2.383 − 105 − 170 − 156 − 1.103,92 − 81 = −2.740,92. Arrendamientos operativos mantienen renta en EBIT, no se capitalizan y descuentan otra vez. Garantías ordinarias se mantienen en costes/circulante; no se resta automáticamente todo pasivo operativo como deuda. Otros saldos y cambios desde octubre limitan el puente: es convención de escenario, no precio transaccional exacto.

## 5. Modelo de diez años y reinversión

Año 1 son los próximos doce meses modelados desde el TTM, no el resto del ejercicio FY27. Ancla 13.799 de ventas y 5.464 de EBIT GAAP. SBC, I+D y costes operativos permanecen. No se anualizan cuatro veces los 2.064 del último trimestre.

- Bajista: crecimiento −10/−5/0/2/3 %, luego 3/2,5/2/2/2 %; márgenes 30/25/22/20/20 %, después 20 %. Impuesto 24 %, descuento 12 %, g terminal 2 %, retorno de reinversión 15 %.
- Central: crecimiento 20/15/10/8/6 %, luego 5/4/3,5/3/3 %; márgenes 40/39/38/37/35 %, luego 34/33/32/31/30 %. Impuesto 21 %, descuento 11 %, g terminal 2,5 %, retorno 20 %.
- Favorable: crecimiento 30/25/20/15/12 %, luego 10/8/6/5/4 %; márgenes 48/48/47/46/45 %, luego 44/43/42/41/40 %. Impuesto 18 %, descuento 10 %, g terminal 3 %, retorno 25 %.

Las tasas de descuento son rentabilidades exigidas del analista, no un WACC observado calibrado con beta/coste de deuda al cierre. Los retornos de reinversión son hipótesis económicas, no ROIC incremental probado. Estos límites justifican screen-grade condicionado y no entrada.

Capex de 5,5 % a 4,5 % de ingresos en diez años, D&A operativa de 2 % a 3 %, y circulante de 12 % del incremento de ingresos. Son supuestos explícitos para financiar transición productiva, no guidance de capex. No se capitaliza I+D para inflar margen. Reinversión física = capex − D&A + Δcirculante. Reinversión económica = máximo(0, ΔNOPAT) / retorno, financiando también expansión de margen. Se descuenta el máximo entre ambas y cero. El campo additional_reinvestment_reserve concilia la fórmula completa NOPAT + D&A − capex − Δcirculante − reserva.

Terminal conserva el máximo entre la necesidad física y NOPAT terminal × g / retorno. No desaparece el coste de mantenimiento en la perpetuidad. El suelo económico domina cuatro años en bajista y central y nueve en favorable; el resto requiere mayor inversión física. La caída de margen no genera liberación gratuita ilimitada de capital. El valor terminal representa 36,96 % / 49,23 % / 65,94 % del EV de los tres escenarios.

## 6. Sensibilidades e inverso

| Sensibilidad central | USD/acción |
|---|---:|
| redemption_cost_zero | 210.26 |
| redemption_cost_162 | 209.56 |
| utb_historical_recognized43 | 210.40 |
| utb_zero | 210.58 |
| utb_double | 209.24 |
| opcash_15pct | 205.75 |
| capex_8pct | 187.56 |
| shares_plus5pct | 199.91 |
| other_unresolved_claims_200 | 209.05 |
| capped_call_assumed_value_100 | 210.34 |
| margins_minus10pp | 149.93 |
| nwc_20pct | 208.90 |
| 7pct_operating_margin_all_years | 19.70 |


Mantener margen operativo de 7 % durante todos los años, cercano al ejercicio deprimido FY24, deja un valor exploratorio de 19,70. No se afirma que ese sea el siguiente resultado: muestra riesgo de reversión más intensa que el caso bajista. Capex de 8 % reduce la central a 187,56; mayor caja operativa de 15 % a 205,75. El margen y crecimiento de largo plazo dominan mucho más que pequeños movimientos del puente.

El inverso desplaza todos los márgenes explícitos y terminales entre −20 y +40 puntos porcentuales, manteniendo el resto del caso central. No encuentra raíz que iguale 606,38 dentro de ese dominio; no fuerza un resultado ni afirma imposibilidad fuera del barrido. El extremo de +40 puntos llevaría margen inicial al 80 % y terminal al 70 %, por encima del margen bruto actual. Para sostener la cotización haría falta otra trayectoria de crecimiento, rentabilidad, reinversión, tasa o activos; no basta dar por buena una perpetuidad con el último trimestre.

## 7. Pares con límites de perímetro

WDC is the closest listed HDD operating peer after the Sandisk separation. Quarter ended October 2, released October 22: revenue $4,381m versus $2,818m, GAAP EBIT $2,046m versus $792m, gross margin 57.8% versus 43.5%. CFO $1,604m less capex $227m gives FCF $1,377m, or $1,298m after an SBC sensitivity of $79m. Prior net income includes a $611m gain on retained Sandisk interest, so EPS comparisons are not purely operating. Its preferred/conversion history and remaining current debt require a separate capital bridge. Similar record margins support evidence of a strong industry cycle, not a perpetual peak assumption.

NTAP is storage systems/software/support, not a second pure HDD manufacturer. Its July 31 quarter has 14 weeks and predates these HDD quarters: sales $2,025m, EBIT $484m, CFO $503m, capex $102m, FCF $401m and SBC $98m. Management estimates $65m revenue from the extra week; do not compare raw growth as homogeneous. Support $720m and public cloud $206m make the mix unlike STX. No comparable EV multiple is assigned, and these two operating references do not close the requirement for two homogeneous valuation peers. NTAP observations reuse independently sourced primary history, with exact filing links in inputs.json.


## 8. Catalizadores, riesgos y pruebas pendientes

IR publicó resultados el 27 de octubre; el exhibit SEC presenta dateline 28 de octubre, aunque fue adjuntado al 8-K del 27. El 10-Q se presentó el 29. Se conservan las fechas distintas sin desplazar artificialmente la publicación. No se ha localizado fecha primaria exacta del siguiente resultado. Dividendo anunciado de 0,76 para enero de 2027 no es fecha de resultados ni nuevo permiso de entrada.

Validaciones que cambiarían la lectura: persistencia del pricing y del coste por terabyte con capacidad adicional; aceptación y fiabilidad de HAMR; cancelaciones/revisiones de acuerdos; inversión de mantenimiento y expansión necesaria; caja fiscal normalizada; composición de compensación y dilución; estado de capped calls, coste efectivo del rescate posterior y capital actualizado. Demanda AI y disciplina de oferta son hipótesis favorables, no garantía contra exceso de capacidad o reducción de inventarios de clientes.

Riesgos: concentración de hiperescaladores, exportaciones y acuerdo BIS, localización de plantas y proveedores, rare earths/componentes, defectos y garantías, transición tecnológica, presión SSD en ciertos usos, impuestos y ciclicidad de márgenes. Los campos de owner FCF y techo de compra permanecen nulos y no se marca valoración integral completada. El informe aporta escenarios auditables, no una recomendación de compra o venta.

## Fuentes principales

- Q1 FY27 10-Q: https://www.sec.gov/Archives/edgar/data/1137789/000113778926000309/stx-20261002.htm
- FY26 10-K: https://www.sec.gov/Archives/edgar/data/1137789/000113778926000159/stx-20260703.htm
- Resultado IR: https://investors.seagate.com/news/news-details/2026/Seagate-Technology-Reports-Fiscal-First-Quarter-2027-Financial-Results/default.aspx
- Exhibit del resultado: https://www.sec.gov/Archives/edgar/data/1137789/000113778926000300/stxq12027pressreleasefinan.htm
- Precio: https://stockanalysis.com/stocks/stx/history/
- Cada dato histórico y ajustes: history/source_index.json y extractos numéricos.
- Pares: comparables/inputs.json, enlaces primarios exactos.
