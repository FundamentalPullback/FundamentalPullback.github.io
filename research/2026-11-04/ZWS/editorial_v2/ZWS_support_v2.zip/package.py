from pathlib import Path
import zipfile,hashlib
P=Path(__file__).parent
files=[p for p in P.rglob('*') if p.is_file() and '__pycache__' not in str(p) and p.suffix not in ['.zip'] and p.name!='manifest.sha256']
with zipfile.ZipFile(P/'ZWS_support_v2.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(files):z.write(f,str(f.relative_to(P)))
files.append(P/'ZWS_support_v2.zip')
(P/'manifest.sha256').write_text('\n'.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+str(f.relative_to(P)) for f in sorted(files))+'\n')
