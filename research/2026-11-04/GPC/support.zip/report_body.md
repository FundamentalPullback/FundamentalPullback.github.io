# GPC: ventas crecientes, rentabilidad y caja por normalizar antes de la separación

Corte de investigación: 4 de noviembre de 2026, 20:28 UTC. USD millones, salvo precio, EPS y acciones en millones. Investigación parcial revisada mediante auditoría independiente, con las reservas indicadas. Sin valoración certificada, cierre integral Stage 3, latestCompleted, Stage 3.5 ni entrada. No modifica gestión ni operaciones.

## 1. Conclusión y alcance

GPC mantiene una red de distribución extensa y crecimiento de ventas, pero el crecimiento no se ha traducido en mejora sostenida del beneficio operativo. EBIT operativo pasa de 1.747,053 en FY23 a 1.229,216 en FY24, 960,651 en FY25 y 912,666 en el TTM septiembre de 2026. La liquidación de pensiones de FY25 está debajo del operativo: no explica por sí sola ese deterioro. Los cargos de First Brands, asbesto, reestructuración y separación tienen distinta naturaleza y no admiten un único addback para fabricar una recuperación.

La mejora de caja requiere descontar financiación de clientes vendida, no solo mirar CFO. FCF TTM de 762,849 menos financiación neta de cuentas a cobrar de 249,979 da 512,870; después de SBC de 56,759, la sensibilidad es 456,111. Ninguna de estas cifras es owner FCF certificado o FCFF.

A040/A052 eran prioridad/elegibilidad histórica, no un DCF reproducible que este informe sustituya. Se conserva el escáner real del 19 de octubre: 130,18, QP 80, Opportunity 100, RSI 50,5 y Stage 2 Sí histórico. Cierre de referencia separado: 124,27 del 3 de noviembre. No se promueve el score ni el filtro técnico antiguo a aprobación actual. No se usa cotización intradía del 4 de noviembre.

Valores bajista, central, favorable, techo de compra, owner FCF y puente integral quedan nulos. La separación prevista, los fondos afectados a prestaciones, la financiación de circulante y la rentabilidad normalizada necesitan conciliación antes de un DCF defendible. Esto no afirma valor cero ni constituye un rechazo permanente; documenta qué evidencia falta.

## 2. Negocio, calidad y resultados recientes

Distribuidor de recambios automotrices y suministros industriales con más de 10.800 ubicaciones en 17 países. Su disponibilidad de producto, red logística y relación con talleres/industria son ventajas operativas; la competencia, mano de obra, transporte, tecnología y condiciones con proveedores determinan cuánto de la venta queda para el accionista. No es un negocio de márgenes de software ni una apuesta homogénea por el consumo automotriz estadounidense.

Q3 ventas 6.521,308 frente a 6.260,232, crecimiento 4,2 %: comparables 2,9 %, adquisiciones 0,9 % y divisa/otros 0,4 %. EBIT operativo 328,484 frente a 334,293; EPS diluido 1,62 en ambos periodos. EPS ajustado 2,07 frente a 1,98 no sustituye el beneficio GAAP. El crecimiento de ventas y margen bruto no evita mayor gasto de personal, fletes, salud, alquiler y sistemas.

Automoción Norteamérica: ventas 2.540,319, comparables +1,7 %, EBITDA de segmento aproximadamente 194 y margen 7,6 %, 40 puntos básicos menos. Automoción internacional: ventas aproximadamente 1.572,392, comparables +1,1 %, EBITDA 141 y margen 9,0 %. Industrial: ventas aproximadamente 2.408,597, comparables +5,5 %, EBITDA 317 y margen 13,2 %, 60 puntos básicos más. Son EBITDA de segmento, no EBIT consolidado; no sumarlos como beneficio disponible sin D&A, costes centrales y ajustes no asignados.

La guía FY26 redujo el máximo de EPS ajustado de 8,00 a 7,75, manteniendo mínimo 7,50. EPS GAAP previsto 5,60–5,85 incluye costes de separación ya incurridos, no un presupuesto completo de costes futuros. CFO previsto 1.000–1.200 y FCF 550–700 son orientación de dirección, no resultados realizados. La tasa fiscal reportada Q3 de 19,5 % y 9M de 21,7 % incorpora créditos renovables, créditos extranjeros y mezcla geográfica; no se perpetúa mecánicamente.

## 3. Historia financiera y reconciliaciones

{HISTORY_TABLE}

Importes en millones. Historia adjunta: tres ejercicios, ocho trimestres comparables y TTM. EBIT operativo = beneficio bruto menos gastos operativos. CFO/capex trimestrales por diferencias de acumulados y Q4 como FY menos 9M. El TTM se comprueba también mediante suma de cuatro trimestres. EPS Q4 y TTM quedan nulos por no haberse recuperado los EPS trimestrales directos necesarios; no se reconstruyen restando EPS anual y nueve meses; medias de acciones no equivalen a acciones actuales. El archivo de historia conserva los límites de cada campo y fuentes primarias.

FY25 EBIT operativo 960,651 frente a EBT más interés neto 215,674: el segundo incluye el cargo no operativo de liquidación de pensiones de 741,967 y otros gastos. En TTM, 912,666 frente a 169,612. Añadir 741,967 al EBIT operativo sería doble cómputo. El beneficio neto TTM de 31,042 incluye estas partidas y efectos fiscales; tampoco es un ancla limpia de rentabilidad futura.

First Brands: cargo FY25 de 150,500 por pérdidas esperadas en rebates y otras cantidades debidas por un proveedor en concurso, dentro del coste de ventas. No es amortización ni dinero que se recupere automáticamente. Asbesto: reestimación FY25 de 103,352, separable del coste del negocio actual pero ligada a una obligación real. Una valoración posterior debe escoger entre flujos de liquidación de esa obligación y descuento explícito de su valor; no descontar ambos sin reconciliación.

Reestructuración: cargos FY24 213,520, FY25 253,961 y TTM 280,070. La recurrencia impide declarar todo coste como excepcional sin demostrar ahorro sostenible. Pagos TTM 262,066. En 9M26, pagos 176,256 y pasivo final 20,822; el cuadro excluye además 6 de inventario liquidado en coste de ventas. Separación: costes 9M 54,912, Q3 21,204. Gastos de integración de adquisiciones reportados 9M 6,092 y Q3 0,803 frente a seis meses cero presentan una asignación temporal no reconciliada; no se fabrican trimestres para cerrar esa diferencia.

D&A TTM 575,329 incluye amortización, pero no se ha recuperado desglose trimestral completo para separar correctamente software, activos físicos e intangibles adquiridos. Amortización anual de intangibles FY25 152,431 no demuestra que cada dólar sea adquirido ni permite imputar proporcionalmente un TTM. FY25 atribuye aproximadamente 40 del aumento de D&A a un ajuste no recurrente de obligaciones de retiro de activos; tampoco se confunde todo el aumento con depreciación normal de nueva tecnología. No añadir todo D&A a una base que ya excluyera amortización. Capex TTM 433,871 y compras de negocios 205,754 son usos diferentes de fondos.

## 4. La calidad de caja y la financiación del circulante

CFO TTM 1.196,720 menos capex 433,871 = FCF 762,849. Está después de intereses e impuestos y antes de adquisiciones; no es FCFF. SBC 56,759 se mantiene como coste económico, no se supone que recomprar acciones elimine su coste.

La facilidad de venta de cuentas a cobrar aumenta el principal vendido pendiente de 1.000 a 1.250 entre diciembre y septiembre. En 9M26, ventas de créditos 7.201,058 menos cobros 6.951,071 aportan 249,987 de financiación neta dentro de CFO. El flujo TTM equivalente es 249,979, no todo el volumen anual rotado de créditos. La facilidad, ampliada el 2 de enero de 2026, vence el 8 de enero de 2027: la renovación coincide con la ventana prevista de separación. Es riesgo de financiación pendiente, no prueba de cancelación ni salida de caja segura de 1.250. El programa incluye recobro y determinadas obligaciones de recompra por deterioro de crédito/devoluciones. Comisiones 9M de 36 están en gasto no operativo.

FCF TTM después de retirar ese incremento de financiación es 512,870. Restando además SBC se obtiene 456,111 como sensibilidad, todavía sin certificar caja distribuible. Si un futuro FCFF reclasifica el saldo vendido como financiación, debe tratar coherentemente comisiones y capital circulante; no descontar el saldo completo y a la vez restaurar exactamente el mismo circulante inicial en el flujo sin explicar el efecto.

Supply-chain finance: obligaciones 3.195,332 frente a 3.129,794 a diciembre, aumento 65,538, incluidas en cuentas a pagar de 6.394,876. Aproximadamente la mitad del pasivo comercial está en ese programa. Plazos con proveedores de 30–360 días. Es financiación operativa relevante: la clasificación en cuentas a pagar no garantiza que los plazos continúen. Tampoco justifica sumar todo como deuda mientras se descuenta de nuevo el mismo capital circulante. Falta normalizar el nivel sostenible y un escenario de reducción de plazos.

## 5. Capital, pensiones, contingencias y separación

Caja septiembre 763,151. Deuda contable: corto plazo 388,088, vencimiento largo corriente 250 y largo no corriente 4.472,149; total 5.110,237. Acciones efectivas al 30 de septiembre y 16 de octubre: 137,864682 millones; promedio diluido Q3 138,331, no un máximo de dilución futura. El principal de commercial paper es aproximadamente 389, distinto del importe contable descontado. Los term loans de 1.000 están incluidos en deuda, no son una adición. Vencen el 28 de octubre de 2027. El revolver de 2.000 no dispuesto no es efectivo; su capacidad disponible se reduce por el respaldo al commercial paper. Falta actualizar íntegramente principal, moneda y costes de emisión; no se presenta deuda contable como principal exacto.

El fondo AFS de 245 está designado a contribuciones de planes de empleo y no se considera efectivo libre. Tras liquidar el plan estadounidense en diciembre de 2025, el excedente original incluía bonos, caja y acciones GPC; estas últimas ya fueron tratadas como recompra no monetaria. No se vuelven a sumar acciones o todo el excedente como activo disponible. El uso ajeno al plan puede soportar impuesto especial de hasta 50 %. El gasto normal de contribuciones definidas sigue siendo remuneración económica aunque se financie temporalmente con excedentes del antiguo plan.

Pasivo de pensiones y prestaciones 218,787 es distinto del plan estadounidense ya liquidado y del fondo AFS. No constituye por sí solo una medición actual completa de déficit actuarial neto ni prueba ausencia de solapamiento con coste laboral. La valoración debe separar servicios corrientes y obligaciones pasadas.

Asbesto: pasivo descontado 281, seguro a cobrar 34, diferencia aritmética 247; rango de pasivo 223–345, diferencia neta 189–311 si el seguro se realiza íntegramente. Importe sin descuento 362. El tipo de descuento pasó de 4,18 % a 5,29 %, de modo que una caída del pasivo contable no demuestra extinción de riesgo. Hay 3.741 demandas pendientes. El seguro no es caja y su cobro/timing puede diferir del pago. Son escenarios de obligación, no un puente certificado.

Garantías de independientes: 484 de préstamos respaldados; la empresa indica reserva de pérdida esperada no material, no ausencia de exposición. Activo y pasivo de standby de 27 cada uno son distintos de la pérdida crediticia esperada. No se descuenta ciegamente toda garantía ni se considera nula.

UTB con intereses y penalidades de diciembre de 2025: aproximadamente 57, de los que 45 afectarían tasa efectiva si se reconocieran. No se ha conciliado importe actual septiembre. El outside-basis extranjero de 1.500 a diciembre no es caja ni impuesto exigible; la empresa afirma reinversión indefinida y no cuantifica impuesto residual. El proyecto fiscal renovable tenía compromiso 43 pendiente a diciembre y liquidación prevista en 2026: sin reconstrucción actual no se resta otra vez como si siguiera íntegro. La tasa fiscal baja no certifica caja liberada.

Separación de Automotive y Motion: objetivo primer trimestre de 2027, sujeto a condiciones. Los estados actuales no reflejan la escisión. No están certificadas aquí las asignaciones de deuda/caja, contratos transitorios, duplicación corporativa, obligaciones laborales ni coste fiscal final. No se suma valor de dos negocios sin quitar costes centrales ni se supone operación cerrada. Los reembolsos IEEPA solicitados/recibidos eran no materiales a septiembre según filing; no se inventa una normalización arancelaria.

## 6. Comparables y evidencia sectorial

{PEERS}

## 7. Próximas pruebas y disciplina de decisión

Q3 publicado el 20 de octubre y 10-Q presentado ese día, verificados directamente. No se ha localizado anuncio primario de fecha exacta del próximo resultado; fechas estimadas de febrero de 2027 no se elevan a confirmación. El objetivo de separación Q1 2027 es un hito distinto de resultados y no una fecha cerrada.

Para cerrar valoración: aislar First Brands/asbesto sin regalar recuperaciones; demostrar rentabilidad después de gastos recurrentes de reestructuración y tecnología; conciliar factoring, SCF y circulante sostenible; separar amortizaciones y capex de mantenimiento; completar deuda nominal, prestaciones, impuestos y gastos de separación; reconciliar al menos dos pares con capital y perímetro homogéneos; financiar crecimiento y recuperación de margen en diez años y terminal. Un simple múltiplo de EPS ajustado no resuelve estas preguntas.

Señales favorables: avance de Industrial, margen bruto, crecimiento comparable y capacidad de servicio. Señales de alarma: caída de EBIT consolidado, menor margen automotriz norteamericano, crecimiento de financiación de circulante, persistencia de reestructuración y costes del cambio de perímetro. La mejora de precio o un score antiguo alto no sustituye esas pruebas.

## Fuentes principales

- Q3 10-Q: https://www.sec.gov/Archives/edgar/data/40987/000004098726000041/gpc-20260930.htm
- FY25 10-K: https://www.sec.gov/Archives/edgar/data/40987/000004098726000003/gpc-20251231.htm
- Q3 comunicado: https://www.genpt.com/2026-10-20-Genuine-Parts-Company-Reports-Third-Quarter-2026-Results
- Precio histórico: https://finance.yahoo.com/quote/GPC/history/?p=GPC
- Historial SEC y cada periodo: history/evidence.json y extractos numéricos portables.
- Pares: comparables/inputs.json con enlaces SEC exactos.
