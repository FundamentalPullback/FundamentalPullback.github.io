# TRMD — TORM: caja fuerte, ciclo excepcional y nueva inversión pendiente de conciliar

Corte de investigación: 4 de noviembre de 2026, 23:19 UTC. Importes en millones de USD salvo acciones, EPS y tarifas diarias. Investigación factual parcial. Auditoría independiente completada para el alcance factual parcial. No constituye valoración integral, aprobación de Stage 3.5 ni entrada.

## 1. Qué cambia y qué falta

El comunicado y el informe intermedio de hoy permiten sustituir expectativas por resultados de Q3. El beneficio y la generación de caja mejoran fuertemente, pero coinciden con tarifas de transporte excepcionalmente altas y un programa de renovación de flota creciente. La empresa ha anunciado ocho LR2 adicionales mediante una JV al 50 % después del balance. No se ha conciliado aquí su coste, financiación ni derechos y garantías. Por tanto, no traslado el beneficio reciente a perpetuidad ni asigno un valor central, rango intrínseco o precio máximo de compra.

El escáner del 4 de noviembre conserva Last 37,64, QP 80 y Opportunity 95. Su exportación indica 17:46:27 sin zona horaria. StockAnalysis documenta cierre regular del mismo día de 37,62. Son referencias distintas y se conservan ambas, sin cierre único conciliado. El fichero no aporta todos los campos de Stage 1 ni Stage 2; el score y el RSI no autorizan una entrada. TRMD representa acciones A de TORM cotizadas en USD en Nasdaq; no se aplica un ratio ADR inventado ni se confunde con la cotización danesa en DKK.

## 2. Historia reproducible, no extrapolación del trimestre

| Periodo | Ingresos | TCE tanker | EBIT | NI consolidado | EPS diluido | CFO | Tangibles cash | Intangibles cash | SBC gasto | CFO − capex |
|---|---|---|---|---|---|---|---|---|---|---|
| 9M2024 | 1,253.80 | 920.10 | 569.30 | 534.10 | 5.61 | 706.10 | 436.20 | 0.90 | n/d | 269.00 |
| FY2023 | 1,520.40 | 1,083.80 | 698.60 | 648.00 | 7.48 | 805.00 | 509.70 | 0.60 | 23.00 | 294.70 |
| FY2024 | 1,559.20 | 1,134.80 | 658.80 | 611.50 | 6.36 | 826.80 | 582.40 | 1.10 | 30.30 | 243.30 |
| FY2025 | 1,339.50 | 909.70 | 356.30 | 286.00 | 2.85 | 498.90 | 308.50 | 1.80 | 34.10 | 188.60 |
| 9M2025 | 986.90 | 658.70 | 255.90 | 199.20 | 1.98 | 363.90 | 91.80 | 0.80 | n/d | 271.30 |
| 9M2026 | 1,564.20 | 1,150.90 | 709.10 | 659.80 | 6.34 | 719.90 | 311.30 | 2.00 | n/d | 406.60 |
| H12025 | 644.30 | 422.20 | 157.00 | 121.60 | 1.20 | 244.40 | 55.70 | 0.40 | n/d | 188.30 |
| H12026 | 1,064.80 | 798.10 | 496.40 | 460.70 | 4.43 | 455.40 | 256.90 | 1.50 | n/d | 197.00 |
| Q12025 | 329.10 | 214.00 | 82.30 | 62.90 | 0.62 | 83.10 | 27.80 | 0.20 | n/d | 55.10 |
| Q12026 | 402.00 | 286.10 | 141.30 | 122.40 | 1.18 | 135.90 | 183.20 | 1.10 | n/d | -48.40 |
| Q22025 | 315.20 | 208.20 | 74.60 | 58.70 | 0.58 | 161.40 | 27.90 | 0.20 | n/d | 133.30 |
| Q22026 | 662.80 | 512.00 | 355.10 | 338.30 | 3.25 | 319.50 | 73.70 | 0.40 | n/d | 245.40 |
| Q32025 | 342.60 | 236.40 | 99.00 | 77.60 | 0.77 | 119.50 | 36.10 | 0.40 | n/d | 83.00 |
| Q32026 | 499.40 | 352.80 | 212.70 | 199.10 | 1.91 | 264.50 | 54.40 | 0.50 | n/d | 209.60 |
| Q42025 | 352.60 | 251.00 | 100.40 | 86.80 | n/d | 135.00 | 216.70 | 1.00 | n/d | -82.70 |
| TTM2026Q3 | 1,916.80 | 1,401.90 | 809.50 | 746.60 | n/d | 854.90 | 528.00 | 3.00 | n/d | 323.90 |
| TTM2025Q3 | 1,292.30 | 873.40 | 345.40 | 276.60 | n/d | 484.60 | 238.00 | 1.00 | n/d | 245.60 |


El TTM a septiembre arroja ingresos de 1.916,8 frente a 1.292,3, EBIT de 809,5 frente a 345,4 y CFO de 854,9 frente a 484,6. Sin embargo, CFO menos toda inversión tangible e intangible en efectivo es 323,9 frente a 245,6, por el mayor desembolso inversor. La diferencia de magnitudes importa: beneficio pico, caja operativa y caja después de compras de activos no son intercambiables.

El gasto SBC anual es 23,0 / 30,3 / 34,1 en FY2023–2025. Los movimientos de patrimonio por SBC difieren y no sustituyen al gasto del periodo; el gasto interino no conciliado queda nulo. Tampoco se suma el valor de nuevos premios al gasto como si fuese una segunda salida de caja.

La tabla mantiene ingresos IFRS, TCE, EBIT, beneficio, caja e inversión separados. El TCE descuenta gastos del viaje y no es equivalente a ingresos contables. Los trimestres calculados por diferencias acumuladas llevan trazabilidad y controles de redondeo en el soporte; EPS acumulado no se transforma en EPS trimestral por una resta silenciosa. Los campos desconocidos son nulos, no ceros.

En Q3, el TCE por día fue 40.102 USD frente a 31.012. El informe describe un mercado beneficiado por el conflicto de Oriente Medio, recorridos más largos, ineficiencias logísticas y utilización de LR2 en crudo. Eso ayuda a explicar la fortaleza operativa, pero no demuestra una tarifa sostenible de ciclo completo ni una causa única del movimiento de la acción. Las cifras reportadas incluyen ganancias por ventas de buques. El soporte muestra EBIT sin esas ganancias como ajuste limitado, no como beneficio normalizado integral.

La guía de 2026 se elevó a TCE de 1.750–1.900 y EBITDA de 1.350–1.500. Al 28 de octubre se había cubierto el 53 % de días de Q4 a 78.419 USD/día. Es cobertura parcial de un trimestre, no un contrato perpetuo para toda la flota. El EBITDA tampoco equivale a caja libre después de reposición de buques, deuda o dividendos.

## 3. La diferencia entre FCF publicado y caja para el propietario

En nueve meses, CFO de 719,9 menos compras tangibles de 311,3 y compras intangibles de 2,0 deja 406,6. El FCF publicado es 485,1 porque emplea CFO más el flujo neto de inversión: incluye ventas de activos de 75,6 y liberación de efectivo restringido de 2,9. Es una definición legítima del emisor, pero no prueba que pueda distribuirse ese importe cada año manteniendo capacidad productiva.

El gasto tangible incorpora flota y dry-docking. No se ha separado una curva de mantenimiento/reposición suficiente por edad de buque, adquisición de capacidad incremental y calendario de diques. La flota operativa era de 95 buques, excluidos los pedidos. Los activos capitalizados de dique ascienden a 115,0 dentro del valor contable de buques de 2.838,2, no a un activo líquido adicional. No añado la depreciación íntegra sin reinversión ni sumo los ingresos de ventas como rentabilidad recurrente.

El CFO contiene intereses pagados y diferencias de cambio realizadas de 54,3 en nueve meses. No es FCFF antes de financiación. El consumo por inventarios, cobros y pagos fue 115,0 frente a 19,8 en el periodo comparable. Tampoco se eliminan estos cambios de capital operativo como si fuesen siempre recuperables. La carga fiscal de resultados de 3,0 y pagos fiscales de 1,9 son cifras observadas, no una tasa terminal certificada aplicable automáticamente a cualquier escenario o jurisdicción.

## 4. Capital histórico y obligaciones posteriores

La caja total de septiembre era 448,7, de la que 2,5 estaba restringida. Caja no restringida mecánica: 446,2. El principal de préstamos era 1.141,6, con 8,7 de pasivos por derecho de uso y 12,5 de costes de financiación diferidos. Así se llega al saldo contable de préstamos de 1.137,8. Deuda de principal más leases menos caja no restringida: 704,1. Es un subtotal histórico, no un puente de valor de las acciones ni saldo actualizado a noviembre. No se suma nuevamente el lease ya incluido en la definición de deuda bruta.

Los vencimientos de principal dentro de un año suman 168,5. La liquidez publicada de 798,7 incluye 350,0 de líneas no utilizadas y también efectivo restringido. Una línea disponible no es caja propia ni valor adicional. La dirección declara cumplimiento de covenants en septiembre y realiza pruebas de continuidad hasta diciembre de 2027; se conserva esa afirmación como evaluación de la dirección, no una garantía independiente de solvencia en todo escenario.

Los compromisos de nuevas construcciones y buques de segunda mano ascienden a 608,8: 191,2 en un año, 80,3 en el segundo, 208,8 en el tercero, 73,5 en el cuarto y 55,0 en el quinto. Otros compromisos suman 6,5. No se deduce todo inmediatamente de la caja como si ya hubiese sido pagado; tampoco se presenta esa caja como enteramente excedentaria ignorando el calendario de inversión.

Después de septiembre se recompraron TORM Alice y TORM Alexandra a sus propietarios de sale-and-leaseback. El informe identifica el evento pero no se ha conciliado en este expediente su desembolso y cancelación de pasivos. También se encargaron ocho LR2 a través de una JV 50/50 con entregas en 2029 y 2030. La participación no permite asumir que basta con la mitad de un precio no publicado, ni que no hay garantías adicionales. El programa de MR y sus opciones debe separarse entre pedidos firmes ya incluidos en septiembre y opciones futuras. No sumo anuncios completos indiscriminadamente al compromiso de 608,8.

Hoy se declaró un dividendo de 138,7, equivalente a 1,35 USD por acción, no reconocido como pasivo al cierre de septiembre. Pago previsto el 2 de diciembre, registro el 17 de noviembre, exdividendo estadounidense el 17 y danés el 16 de noviembre. No es una rentabilidad gratuita: para comparar caja o NAV después de distribución debe considerarse una vez. Los dividendos pagados durante nueve meses, 388,7, ya están reflejados en la caja del balance y no se vuelven a restar.

## 5. NAV del emisor: prueba de sensibilidad, no valoración independiente

El emisor publica NAV de 4.062,2 y 39,60 por acción usando valoraciones de brokers para buques: 4.332,5 para la flota y 697,0 para buques adquiridos o pedidos aún no entregados. Su cálculo ya descuenta 615,3 de compromisos de inversión. Restarlos otra vez produciría doble cómputo. También resta deuda bruta de 1.150,3 y mantiene caja total de 448,7, incluido efectivo restringido. Los derivados netos de 21,1 ya están en partidas de cobros y pagos; no se añaden como caja separada.

| Recorte de brokers a flota existente | NAV mecánico por acción tras dividendo |
|---|---|
| 0% | 38.20 USD |
| 10% | 33.98 USD |
| 20% | 29.77 USD |


El cálculo usa las cifras agregadas redondeadas: 4.062,2 / 102,7 = 39,5540 y (4.062,2 − 138,7) / 102,7 = 38,2035. No parte de restar 1,35 al NAV por acción publicado de 39,60, que produciría 38,25; la diferencia procede de la precisión disponible en los datos publicados, no de una corrección del NAV del emisor.

Esta sensibilidad conserva la definición del NAV publicado y sólo resta el dividendo recién declarado y, cuando se indica, un recorte al valor de brokers de la flota existente. No cubre impuestos de venta, costes de transacción, liquidez de desinversión, compromisos de charter excluidos de la definición del emisor, revisión de valor de pedidos, financiación de la nueva JV ni las recompras de leaseback posteriores. Tampoco certifica valor liquidativo realizable. Por eso ninguno de esos resultados ocupa los campos de valor intrínseco, caso bajista, central o alcista.

Las 102,7 millones de acciones al cierre están redondeadas. La media diluida Q3 fue 104,4, frente a 102,4 de media básica. Hay premios y opciones con ejercicio vinculado a la cotización y ajuste por dividendos. La media diluida no certifica acciones futuras, y el NAV por acción publicado no equivale a una valoración que incorpore toda dilución futura. Oaktree vendió sus acciones restantes en octubre; una venta secundaria no se trata como una ampliación de capital o caja recibida por TORM.

## 6. Comparación operativa limitada

Scorpio Tankers publicó Q3 el 28 de octubre. Su TCE fue 249,1 frente a 232,9, con tarifa diaria de 37.508 frente a 26.231 y flota media de 75,1 frente a 99,0. La menor flota y las ventas hacen que ingresos, ganancias y caja no sean comparables sin ajustar perímetro. Su beneficio de 224,3 contiene 152,6 de ganancias de ventas y 55,6 de pérdidas por valoración de pasivos; el beneficio ajustado comunicado es 127,4. Este contraste apoya que el ciclo sectorial es fuerte, pero no valida un múltiplo de beneficio pico ni un precio objetivo para TORM. No se usa una mediana de EV/EBIT ni un balance de STNG como sustituto del de TRMD.

## 7. Próximos pasos y estado

La publicación Q3 y la llamada de hoy son eventos ya ocurridos. No se ha revisado aquí la transcripción completa ni se ha localizado una fecha primaria confirmada para la siguiente publicación de resultados. El dividendo tiene fechas primarias verificadas y no se confunde con earnings.

Para valorar de forma integral faltan: tarifas de ciclo y escenarios de reversión; inversión de mantenimiento y reposición por edad y diques; obligaciones y financiación de la JV y recompras posteriores; caja mínima y capital distribuible; calendario de amortización/dilución; tratamiento fiscal y requisitos ambientales relevantes; pares ajustados por flota y rentas; y coste de capital calibrado. El sector está expuesto a sanciones, rutas, seguros, carbono y normativa marítima; no se afirma que el cierre normativo esté completo ni que esas obligaciones sean cero.

Decisión: mantener como investigación parcial y pendiente de normalización. No rechazo definitivo por mala calidad ni aprobación por aparente descuento a NAV. Valores intrínsecos, owner FCF, puente integral y techo de compra quedan nulos; no se modifica cartera, gestión u órdenes.

### Pros ES
- Los resultados Q3 ya están disponibles y muestran una mejora fuerte de tarifas, beneficio y caja, con datos primarios reproducibles.
- La compañía declara cumplimiento de covenants y 350,0 millones de líneas no utilizadas, sin confundirlas con caja propia.
- El NAV y los compromisos se pueden contrastar explícitamente, evitando volver a descontar el capex ya incluido.

### Contras ES
- Las tarifas excepcionales no justifican perpetuar el beneficio reciente ni certificar un valor intrínseco.
- La nueva JV, las recompras de leaseback y la reposición de flota impiden certificar capital distribuible y owner FCF.
- El NAV depende de precios de brokers y no incorpora automáticamente todos los costes, dilución y hechos posteriores.

### Pros EN
- Published Q3 results show stronger rates, earnings and cash generation, supported by reproducible primary data.
- Management reports covenant compliance and USD 350.0 million of undrawn facilities, kept separate from owned cash.
- Disclosed NAV and commitments can be reconciled without deducting the same committed capex twice.

### Cons EN
- Exceptional freight rates do not justify perpetuating recent earnings or certifying intrinsic value.
- The new joint venture, subsequent leaseback repurchases and fleet replacement prevent certification of distributable capital and owner free cash flow.
- Broker-based NAV does not automatically capture all costs, dilution and subsequent developments.

## Fuentes

- [q3](https://s202.q4cdn.com/126069760/files/content_files/TORM-Q3-2026-Report.pdf)
- [release](https://www.torm.com/news/company-announcements/company-announcements-details/2026/TORM-plc-Q3-2026-Results-Dividend-Distribution-and-Financial-Outlook-2026/default.aspx)
- [annual](https://www.sec.gov/Archives/edgar/data/1655891/000162828026011954/trmd-20251231.htm)
- [calendar](https://www.torm.com/investor/events/default.aspx)
- [price](https://stockanalysis.com/stocks/trmd/history/)
- [peer_STNG](https://www.scorpiotankers.com/scorpio-tankers-inc-announces-financial-results-for-the-third-quarter-of-2026-and-an-increase-to-its-quarterly-dividend/)

Los archivos history/sources.json y field_lineage.json aportan las fuentes primarias y la trazabilidad adicional de cada periodo.
