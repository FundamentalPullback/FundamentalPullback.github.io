CTSH and UNFI: current-price research, November5,2026.
CTSH B V4 is a separate prospective proposal, NOT ACTIVE. No future observation window is assigned and no position/absence of position is inferred. UNFI remains observation.
Economic models and earlier proposals remain unchanged. No personal account data or whole third-party source bodies are included. Reproduce each comparison with its local reproduce.py.
A quote, publication, or a technical condition alone does not authorize an order.
